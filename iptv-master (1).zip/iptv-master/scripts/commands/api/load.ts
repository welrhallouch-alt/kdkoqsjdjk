import { downloadData } from '../../api'

async function main() {
  await downloadData()
}

main()
